from pathlib import Path
import sys,os
ROOT=Path(__file__).resolve().parents[1];os.environ['PSET3_V2_ROOT']=str(ROOT);sys.path.insert(0,str(ROOT))
from src.negocio import main
if __name__=='__main__':
 from verificar_fase import entrada
 entrada('negocio',main)
